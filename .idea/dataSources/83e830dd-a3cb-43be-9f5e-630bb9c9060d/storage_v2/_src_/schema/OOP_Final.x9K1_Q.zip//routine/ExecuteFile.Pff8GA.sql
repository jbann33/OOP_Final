CREATE PROCEDURE ExecuteFile(IN QueryId  INT, IN fileId INT, IN fileName VARCHAR(50), IN fileType VARCHAR(50),
                             IN fileSize INT, IN path VARCHAR(100), IN dirId INT)
  BEGIN

	# INSERT
    IF (QueryId = 10) THEN
    BEGIN
		INSERT INTO		File(fileName,
							 fileType,
							 fileSize,
                             path)
		VALUES( fileName,
				fileType,
                fileSize,
                path);
                
		SELECT LAST_INSERT_ID();
        END;
	
    # UPDATE
    ELSEIF (QueryId = 20) THEN
    BEGIN
		UPDATE		File a
        SET			a.fileName = IFNULL(fileName, a.fileName),
					a.fileType = IFNULL(fileType, a.fileType),
                    a.fileSize = IFNULL(fileSize, a.fileSize),
                    a.path = IFNULL(path, a.path)
		WHERE		a.fileId = fileId;
        
        SELECT ROW_COUNT();
        END;
	
    # DELETE
    ELSEIF (QueryId = 30) THEN
    BEGIN
		DELETE
        FROM		File
        WHERE		fileId = fileId;
        END;
        
END IF;
END;

