CREATE PROCEDURE GetDirectory(IN QueryId INT, IN dirId INT)
  BEGIN
	IF (QueryId = 10) THEN
	BEGIN
		SELECT 		a.dirId,		
					a.dirName,
					a.dirSize,
                    a.numberOfFiles,
                    a.path
		FROM		Directory a
		WHERE		a.dirId = dirId;
        END;
        
	ELSEIF (QueryId = 20) THEN
    BEGIN
		SELECT		a.dirId,
					a.dirName,
					a.dirSize,
                    a.numberOfFiles,
                    a.path
		FROM		Directory a;
        END;
END IF;
END;

