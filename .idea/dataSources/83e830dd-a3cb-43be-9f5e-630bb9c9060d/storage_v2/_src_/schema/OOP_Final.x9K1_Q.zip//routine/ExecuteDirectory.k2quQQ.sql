CREATE PROCEDURE ExecuteDirectory(IN QueryId       INT, IN dirId INT, IN dirName VARCHAR(50), IN dirSize INT,
                                  IN numberOfFiles INT, IN path VARCHAR(100))
  BEGIN

	# INSERT
    IF (QueryId = 10) THEN
    BEGIN
		INSERT INTO		Directory(  dirName,
									dirSize,
                                    numberOfFiles,
                                    path)
		VALUES( dirName,
				dirSize,
                numberOfFiles,
                path);
		
        SELECT LAST_INSERT_ID();
        END;
	
    # UPDATE
    ELSEIF (QueryId = 20) THEN
    BEGIN
		UPDATE		Directory a
        SET			a.dirName = IFNULL(dirName, a.dirName),
					a.dirSize = IFNULL(dirSize, a.dirSize),
                    a.numberOfFiles = IFNULL(numberOfFiles, a.numberOfFiles),
                    a.path = IFNULL(path, a.path)
		WHERE		a.dirId = dirId;
        
        SELECT ROW_COUNT();
        END;
	
    # DELETE
    ELSEIF (QueryId = 30) THEN
    BEGIN
		DELETE
        FROM		Directory
        WHERE		dirId = dirId;
        
        SELECT ROW_COUNT();
        END;
        
END IF;
END;

