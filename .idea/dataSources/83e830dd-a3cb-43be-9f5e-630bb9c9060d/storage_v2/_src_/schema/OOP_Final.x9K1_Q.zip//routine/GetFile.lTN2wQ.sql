CREATE PROCEDURE GetFile(IN QueryId INT, IN fileId INT)
  BEGIN
	IF (QueryId = 10) THEN
    BEGIN
		SELECT		a.fileName,
					a.fileType,
                    a.fileSize,
                    a.path
		FROM		File a
        WHERE		A.fileId = fileId;
        END;
        
	ELSEIF (QueryId = 20) THEN
    BEGIN
		SELECT		a.fileName,
					a.fileType,
                    a.fileSize,
                    a.path
		FROM		File a;
        END;
	
END IF;
END;

